// web/app.js (v0.3.2) -- compact, with safe error hooks and WS auto-connect
'use strict';
const $=s=>document.querySelector(s), $$=s=>Array.from(document.querySelectorAll(s));
let ws=null, sessionDir=null, activePageIndex=-1;
let state={pages:[], ai:new Array(8).fill(0), ao:[0,0], do:new Array(8).fill(0), tc:[]};

window.onerror=function(msg,src,line,col,err){
  console.error('[UI] Error:', msg, src, line, col, err);
  try{ alert('UI error: '+msg+'\nSee console for details.'); }catch(_){}
};
window.onunhandledrejection=function(e){
  console.error('[UI] Promise rejection:', e?.reason||e);
  try{ alert('UI promise error: '+(e?.reason?.message||e?.reason||e)); }catch(_){}
};

document.addEventListener('DOMContentLoaded', ()=>{
  console.log('[BOOT] app.js v0.3.2');
  wireUI(); ensureStarterPage(); connect();
});

function wireUI(){
  const el=(id)=>$(id);
  el('#connectBtn').onclick=()=>connect();
  el('#setRate').onclick=async()=>{
    const hz=parseFloat($('#rate').value||'100');
    await fetch('/api/acq/rate',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({hz})});
  };
  el('#editConfig').onclick=()=>openJsonEditor('Config','/api/config');
  el('#editPID').onclick=()=>openJsonEditor('PID','/api/pid');
  el('#editScript').onclick=()=>openJsonEditor('Script','/api/script');
  el('#recall').onclick=()=>openRecall();
  el('#addPage').onclick=()=>addPage();
  $$('.palette [data-add]').forEach(b=>b.onclick=()=>addWidget(b.dataset.add));
}

function connect(){
  if(ws && ws.readyState===WebSocket.OPEN) return;
  const url=`ws://${location.host}/ws`;
  console.log('[WS] connecting to',url);
  ws = new WebSocket(url);
  ws.onopen = ()=>{ console.log('[WS] open'); $('#connectBtn').textContent='Connected'; };
  ws.onclose= e =>{ console.warn('[WS] close',e.code,e.reason); $('#connectBtn').textContent='Connect'; };
  ws.onerror= e =>{ console.error('[WS] error',e); };
  ws.onmessage = evt => {
    let msg; try{ msg=JSON.parse(evt.data);}catch(err){ console.error('[WS] parse',err); return; }
    if(msg.type==='session'){ sessionDir=msg.dir; $('#session').textContent=`Session: ${sessionDir}`; }
    else if(msg.type==='tick'){
      state.ai=msg.ai||state.ai; state.ao=msg.ao||state.ao; state.do=msg.do||state.do; state.tc=msg.tc||state.tc;
      window.lastTelemetry=msg.pid||[]; paintActivePage();
    }
  };
  if(!window._wsPing) window._wsPing=setInterval(()=>{ try{ if(ws && ws.readyState===WebSocket.OPEN) ws.send('k'); }catch(_){ } }, 3000);
}

function addPage(){ const id='p'+Date.now(); state.pages.push({id,name:`Page ${state.pages.length+1}`,widgets:[]}); refreshPages(); setActivePage(state.pages.length-1); }
function refreshPages(){ const box=$('#pages'); box.innerHTML=''; state.pages.forEach((p,i)=>{const b=document.createElement('button'); b.textContent=p.name; b.onclick=()=>setActivePage(i); box.appendChild(b);}); if(state.pages.length && activePageIndex<0) setActivePage(0); }
function setActivePage(i){ activePageIndex=i; paintActivePage(); }
function ensureStarterPage(){ if(state.pages.length===0){ const id='p'+Date.now(); const chart={id:'w'+(Date.now()+1),type:'chart',x:40,y:40,w:420,h:240,opts:defaultOpts('chart')}; const gauge={id:'w'+(Date.now()+2),type:'gauge',x:480,y:40,w:300,h:240,opts:defaultOpts('gauge')}; state.pages.push({id,name:'Page 1',widgets:[chart,gauge]}); refreshPages(); setActivePage(0);} }

function addWidget(type){ if(activePageIndex<0) addPage(); const p=state.pages[activePageIndex]; const id='w'+Date.now(); const base={id,type,x:40+20*p.widgets.length,y:40+20*p.widgets.length,w:360,h:220,opts:defaultOpts(type)}; p.widgets.push(base); paintActivePage(); }
function defaultOpts(type){ switch(type){ case 'chart': return {title:'Chart',series:[sel('ai',0)],span:10}; case 'gauge': return {title:'Gauge',needles:[sel('ai',0)],min:0,max:10}; case 'bars': return {title:'Bars',series:[sel('ai',0),sel('ai',1)],min:0,max:10}; case 'dobutton': return {title:'Valve A',doIndex:0,activeHigh:true,mode:'momentary',buzzHz:5}; case 'pidpanel': return {title:'PID',loopIndex:0}; } }
function sel(kind,index){ return {kind,index,name:`${kind}${index}`,slope:1,offset:0,units:''}; }

function paintActivePage(){ const c=$('#canvas'); if(!c) return; c.innerHTML=''; if(activePageIndex<0) return; const p=state.pages[activePageIndex]; p.widgets.forEach(w=>mountWidget(c,p,w)); }
function mountWidget(canvas,page,w){ const el=document.createElement('div'); el.className='widget'; el.style.left=w.x+'px'; el.style.top=w.y+'px'; el.style.width=w.w+'px'; el.style.height=w.h+'px'; el.innerHTML=`<header><span class="title">${w.opts.title||w.type}</span><span><button data-cfg>⚙︎</button><button data-del>✕</button><span class="handle">⣿</span></span></header><div class="content"></div>`; const content=el.querySelector('.content'); let dx=0,dy=0,drag=false; el.querySelector('.handle').onmousedown=e=>{drag=true;dx=e.clientX-w.x;dy=e.clientY-w.y;}; window.addEventListener('mousemove',e=>{if(!drag)return; w.x=e.clientX-dx; w.y=e.clientY-dy; el.style.left=w.x+'px'; el.style.top=w.y+'px';}); window.addEventListener('mouseup',()=>drag=false);
  el.querySelector('[data-cfg]').onclick=()=>openWidgetConfig(page,w); el.querySelector('[data-del]').onclick=()=>{page.widgets=page.widgets.filter(x=>x.id!==w.id); paintActivePage();};
  if(w.type==='chart') renderChart(content,w); if(w.type==='gauge') renderGauge(content,w); if(w.type==='bars') renderBars(content,w); if(w.type==='dobutton') renderDOButton(content,w); if(w.type==='pidpanel') renderPID(content,w);
  canvas.appendChild(el);
}

function valueFor(sel){ let raw=0; if(sel.kind==='ai') raw=state.ai[sel.index]||0; if(sel.kind==='ao') raw=state.ao[sel.index]||0; if(sel.kind==='do') raw=state.do[sel.index]||0; if(sel.kind==='tc') raw=state.tc[sel.index]||0; return sel.slope*raw + sel.offset; }

function renderChart(content,w){ const cvs=document.createElement('canvas'); cvs.className='chart-canvas'; content.appendChild(cvs); const ctx=cvs.getContext('2d'); const buf=w._buf=w._buf||[];
  function frame(){ const now=performance.now()/1000, vals=w.opts.series.map(s=>valueFor(s)); buf.push({t:now,v:vals}); const span=w.opts.span||10; while(buf.length && (now-buf[0].t)>span) buf.shift(); const W=cvs.width=content.clientWidth, H=cvs.height=content.clientHeight; ctx.clearRect(0,0,W,H); if(!buf.length){ requestAnimationFrame(frame); return; } const t0=buf[0].t, t1=buf[buf.length-1].t, dt=t1-t0||1; const perMin=[], perMax=[]; for(let si=0; si<w.opts.series.length; si++){ let mn=Infinity,mx=-Infinity; for(const b of buf){ const y=b.v[si]; if(y<mn) mn=y; if(y>mx) mx=y; } perMin[si]=mn; perMax[si]=mx; } ctx.strokeStyle='#3b425e'; ctx.lineWidth=1; ctx.strokeRect(40,10,W-50,H-30);
    w.opts.series.forEach((s,si)=>{ ctx.beginPath(); ctx.lineWidth=1.5; ctx.strokeStyle=`hsl(${(si*70)%360} 70% 60%)`; buf.forEach((b,j)=>{ const x=40+(W-50)*((b.t-t0)/dt); const mn=perMin[si], mx=perMax[si], rng=(mx-mn)||1; const y=10+(H-40)*(1-((b.v[si]-mn)/rng)); if(j===0) ctx.moveTo(x,y); else ctx.lineTo(x,y); }); ctx.stroke(); });
    requestAnimationFrame(frame);
  } frame();
}

function renderGauge(content,w){ const svgNS='http://www.w3.org/2000/svg'; const svg=document.createElementNS(svgNS,'svg'); svg.setAttribute('class','gauge'); content.appendChild(svg);
  function tick(){ const W=content.clientWidth,H=content.clientHeight; svg.setAttribute('viewBox',`0 0 ${W} ${H}`); svg.replaceChildren(); const cx=W/2, cy=H*0.9, r=Math.min(W,H)*0.8/2; const min=w.opts.min||0, max=w.opts.max||10; const arc=document.createElementNS(svgNS,'path'); arc.setAttribute('d',`M ${cx-r} ${cy} A ${r} ${r} 0 0 1 ${cx+r} ${cy}`); arc.setAttribute('stroke','#3b425e'); arc.setAttribute('fill','none'); arc.setAttribute('stroke-width','8'); svg.appendChild(arc);
    w.opts.needles.forEach((s,si)=>{ const needle=document.createElementNS(svgNS,'line'); needle.setAttribute('x1',cx); needle.setAttribute('y1',cy); const v=valueFor(s), frac=(v-min)/(max-min), ang=Math.PI*(1-frac); const x=cx + r*Math.cos(ang), y=cy - r*Math.sin(ang); needle.setAttribute('x2',x); needle.setAttribute('y2',y); needle.setAttribute('stroke',`hsl(${(si*70)%360} 70% 60%)`); needle.setAttribute('stroke-width','4'); svg.appendChild(needle); });
    requestAnimationFrame(tick);
  } tick();
}

function renderBars(content,w){ const wrap=document.createElement('div'); wrap.className='bars'; content.appendChild(wrap); const min=w.opts.min||0,max=w.opts.max||10; const bars=w.opts.series.map((s,si)=>{ const bar=document.createElement('div'); bar.className='bar'; const fill=document.createElement('div'); fill.className='fill'; fill.style.background=`hsl(${(si*70)%360} 70% 60%)`; bar.appendChild(fill); wrap.appendChild(bar); return {fill,sel:s}; });
  (function tick(){ bars.forEach(b=>{ const v=valueFor(b.sel), frac=(v-min)/(max-min); b.fill.style.height=`${100*Math.max(0,Math.min(1,frac))}%`; }); requestAnimationFrame(tick); })();
}

function renderDOButton(content,w){ const b=document.createElement('button'); b.className='do-btn'; b.textContent=w.opts.title||'DO'; content.appendChild(b); const idx=w.opts.doIndex|0, activeHigh=!!w.opts.activeHigh;
  if(w.opts.mode==='momentary'){ b.onmousedown=()=>fetch('/api/do/set',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({index:idx,state:true,active_high:activeHigh})}); b.onmouseup=()=>fetch('/api/do/set',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({index:idx,state:false,active_high:activeHigh})}); b.onmouseleave=b.onmouseup; }
  else if(w.opts.mode==='buzz'){ b.onmousedown=()=>fetch('/api/do/buzz/start',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({index:idx,hz:w.opts.buzzHz||5,active_high:activeHigh})}); b.onmouseup=()=>fetch('/api/do/buzz/stop',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({index:idx,hz:w.opts.buzzHz||5,active_high:activeHigh})}); b.onmouseleave=b.onmouseup; }
  else { b.onclick=()=>{ const newState=!(state.do[idx]|0); fetch('/api/do/set',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({index:idx,state:newState,active_high:activeHigh})}); }; }
}

async function renderPID(content,w){ content.innerHTML=''; const data=await fetch('/api/pid').then(r=>r.json()).catch(_=>({loops:[]})); const loops=data.loops||[]; const i=Math.min(w.opts.loopIndex|0, loops.length-1); if(i<0){ content.textContent='No PID loops defined.'; return; } const L=loops[i];
  const grid=document.createElement('div'); grid.className='pid-grid'; content.appendChild(grid);
  grid.innerHTML=`<label>Name<input id="nm" value="${L.name||''}"></label><label>Target<input id="tgt" type="number" value="${L.target||0}"></label><label>P<input id="kp" type="number" step="0.01" value="${L.kp||0}"></label><label>I<input id="ki" type="number" step="0.01" value="${L.ki||0}"></label><label>D<input id="kd" type="number" step="0.01" value="${L.kd||0}"></label><label>I limit (|abs|)<input id="ilim" type="number" step="0.01" value="${Math.max(Math.abs(L.i_min||0),Math.abs(L.i_max||0))}"></label><label>Err limit (|abs|)<input id="elim" type="number" step="0.01" value="${Math.max(Math.abs(L.err_min||0),Math.abs(L.err_max||0))}"></label><button id="save">Save</button><button id="enable">${L.enabled?'Disable':'Enable'}</button><div id="errtxt">Err: 0</div>`;
  grid.querySelector('#save').onclick=async()=>{ const absI=parseFloat(grid.querySelector('#ilim').value||'0'); const absE=parseFloat(grid.querySelector('#elim').value||'0'); L.name=grid.querySelector('#nm').value; L.target=parseFloat(grid.querySelector('#tgt').value||'0'); L.kp=parseFloat(grid.querySelector('#kp').value||'0'); L.ki=parseFloat(grid.querySelector('#ki').value||'0'); L.kd=parseFloat(grid.querySelector('#kd').value||'0'); L.i_min=-absI; L.i_max=absI; L.err_min=-absE; L.err_max=absE; await fetch('/api/pid',{method:'PUT',headers:{'Content-Type':'application/json'},body:JSON.stringify({loops:loops})}); };
  grid.querySelector('#enable').onclick=async()=>{ L.enabled=!L.enabled; await fetch('/api/pid',{method:'PUT',headers:{'Content-Type':'application/json'},body:JSON.stringify({loops:loops})}); renderPID(content,w); };
  const errtxt=grid.querySelector('#errtxt'); (function update(){ const tel=window.lastTelemetry||[]; const rec=tel.find(r=>r.name===L.name); if(rec) errtxt.textContent=`Err: ${rec.err.toFixed(3)}`; requestAnimationFrame(update); })();
}

function openWidgetConfig(page,w){ const m=$('#modal'); m.classList.remove('hidden'); const card=document.createElement('div'); card.className='card'; m.innerHTML=''; m.appendChild(card); card.innerHTML=`<h3>Configure ${w.type}</h3>`; const form=document.createElement('div'); card.appendChild(form);
  if(w.type==='chart'||w.type==='bars'||w.type==='gauge'){ form.innerHTML=`<label>Title <input id="title" value="${w.opts.title||''}"></label><div id="series"></div><button id="addS">+ Add signal</button>${w.type==='chart'?'<label>Span (s) <input id="span" type="number" value="'+(w.opts.span||10)+'"></label>':''}${w.type!=='chart'?'<label>Min <input id="min" type="number" value="'+(w.opts.min||0)+'"></label>':''}${w.type!=='chart'?'<label>Max <input id="max" type="number" value="'+(w.opts.max||10)+'"></label>':''}`;
    const S=form.querySelector('#series'); function drawRows(){ S.innerHTML=''; const rows=(w.type==='gauge'? w.opts.needles : w.opts.series); rows.forEach((s,i)=>{ const row=document.createElement('div'); row.innerHTML=`<select class="kind"><option ${s.kind==='ai'?'selected':''} value="ai">AI</option><option ${s.kind==='ao'?'selected':''} value="ao">AO</option><option ${s.kind==='do'?'selected':''} value="do">DO</option><option ${s.kind==='tc'?'selected':''} value="tc">TC</option></select><input class="index" type="number" min="0" value="${s.index}"><input class="name" placeholder="name" value="${s.name||''}"><input class="slope" type="number" step="0.001" value="${s.slope||1}"><input class="offset" type="number" step="0.001" value="${s.offset||0}"><input class="units" placeholder="units" value="${s.units||''}"><button class="del">✕</button>`;
      row.querySelector('.del').onclick=()=>{ rows.splice(i,1); drawRows(); };
      ['kind','index','name','slope','offset','units'].forEach(k=>{ row.querySelector('.'+k).oninput=e=>{ s[k]=(k==='kind'||k==='name'||k==='units')? e.target.value : parseFloat(e.target.value||'0'); }; });
      S.appendChild(row);
    }); }
    drawRows(); form.querySelector('#addS').onclick=()=>{ (w.type==='gauge'? w.opts.needles : w.opts.series).push(sel('ai',0)); drawRows(); };
    const title=form.querySelector('#title'); title.oninput=()=>{ w.opts.title=title.value; }; const span=form.querySelector('#span'); if(span) span.oninput=()=>{ w.opts.span=parseFloat(span.value||'10'); };
    const min=form.querySelector('#min'); if(min) min.oninput=()=>{ w.opts.min=parseFloat(min.value||'0'); }; const max=form.querySelector('#max'); if(max) max.oninput=()=>{ w.opts.max=parseFloat(max.value||'10'); };
  } else if(w.type==='dobutton'){ form.innerHTML=`<label>Title <input id="title" value="${w.opts.title||''}"></label><label>DO Index <input id="idx" type="number" min="0" max="7" value="${w.opts.doIndex|0}"></label><label><input id="ah" type="checkbox" ${w.opts.activeHigh?'checked':''}> Active High</label><label>Mode <select id="mode"><option ${w.opts.mode==='momentary'?'selected':''} value="momentary">Momentary</option><option ${w.opts.mode==='toggle'?'selected':''} value="toggle">Toggle</option><option ${w.opts.mode==='buzz'?'selected':''} value="buzz">Buzz (while held)</option></select></label><label>Buzz Hz <input id="bhz" type="number" value="${w.opts.buzzHz||5}"></label>`;
    ['title','idx','bhz'].forEach(id=> form.querySelector('#'+id).oninput=e=>{ if(id==='title') w.opts.title=e.target.value; else if(id==='idx') w.opts.doIndex=parseInt(e.target.value||'0'); else w.opts.buzzHz=parseFloat(e.target.value||'5'); });
    form.querySelector('#ah').onchange=e=> w.opts.activeHigh=e.target.checked; form.querySelector('#mode').onchange=e=> w.opts.mode=e.target.value;
  } else if(w.type==='pidpanel'){ form.innerHTML=`<label>Loop Index <input id="idx" type="number" min="0" value="${w.opts.loopIndex|0}"></label>`; form.querySelector('#idx').oninput=e=> w.opts.loopIndex=parseInt(e.target.value||'0'); }
  const actions=document.createElement('div'); actions.style='margin-top:8px; display:flex; gap:8px; justify-content:flex-end'; const ok=document.createElement('button'); ok.textContent='Close'; ok.onclick=()=>{ $('#modal').classList.add('hidden'); $('#modal').innerHTML=''; }; actions.appendChild(ok); card.appendChild(actions);
}

async function openJsonEditor(title,url){ const data=await fetch(url).then(r=>r.json()); const m=$('#modal'); m.classList.remove('hidden'); const card=document.createElement('div'); card.className='card'; m.innerHTML=''; m.appendChild(card); card.innerHTML=`<h3>${title}</h3>`; const ta=document.createElement('textarea'); ta.style.width='100%'; ta.style.height='60vh'; ta.value=JSON.stringify(data,null,2);
  const row=document.createElement('div'); row.style='display:flex; gap:8px; justify-content:flex-end; margin-top:8px;'; const save=document.createElement('button'); save.textContent='Save'; const cancel=document.createElement('button'); cancel.textContent='Close';
  cancel.onclick=()=>{ m.classList.add('hidden'); m.innerHTML=''; }; save.onclick=async()=>{ try{ const body=JSON.parse(ta.value); await fetch(url,{method:'PUT',headers:{'Content-Type':'application/json'},body:JSON.stringify(body)}); cancel.onclick(); }catch(e){ alert('Invalid JSON: '+e.message);} };
  row.appendChild(save); row.appendChild(cancel); card.appendChild(ta); card.appendChild(row);
}

async function openRecall(){ const list=await fetch('/api/logs').then(r=>r.json()); const m=$('#modal'); m.classList.remove('hidden'); const card=document.createElement('div'); card.className='card'; m.innerHTML=''; m.appendChild(card); card.innerHTML='<h3>Logs</h3>'; const ul=document.createElement('ul'); list.forEach(s=>{ const li=document.createElement('li'); li.innerHTML=`<a href="/api/logs/${s}/csv">${s}</a>`; ul.appendChild(li); }); const close=document.createElement('button'); close.textContent='Close'; close.onclick=()=>{ m.classList.add('hidden'); m.innerHTML=''; }; card.appendChild(ul); card.appendChild(close); }
